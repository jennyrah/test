for(var i = 1 ; i <= 7 ; i++) {
  for(var j = 1 ; j <= i ; j++) {
    document.write('#');
  }
  document.write('<br/>');
}