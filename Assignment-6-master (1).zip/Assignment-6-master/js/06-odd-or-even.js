for(var i = 0;i <= 15; i++) {
  if(i%2 == 0) {
    window.console.log(i + " is even");
  }
  else {
    window.console.log(i + " is odd");
  }
}