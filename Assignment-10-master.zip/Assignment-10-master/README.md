# Assignment 10
 CS 648 jQuery 02

This project is a part of Assignment 10 for course **_CS648_**.

| Language | Platform | Author |
| -------- | --------|--------|
| HTML,CSS,JS,jQuery |  Basic Web App| Shubham Kale|

# Sample HTML website 

Sample HTML/CSS web app that you can modify further and use it for assignment for course **_CS648_** . 


## Contributing
This project has adopted the [Prof Zak Basic Lectures](https://www.youtube.com/watch?v=7EWBHppYbmM&feature=youtu.be).
For more information 
contact [skale3178@sdsu.edu](mailto:skale3178@sdsu.edu) with any additional questions or comments.



 


 




