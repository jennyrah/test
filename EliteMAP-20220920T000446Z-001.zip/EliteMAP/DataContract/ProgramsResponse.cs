﻿using System.Collections.Generic;

namespace DataContract
{
    public class ProgramsResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public string Success { get; set; }
        public List<ProgramsData> Data { get; set; }
    }
}
