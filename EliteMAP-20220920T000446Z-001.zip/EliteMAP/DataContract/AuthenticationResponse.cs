﻿namespace DataContract
{
    public class AuthTokenResponse
    {
        public string access_token { get; set; }
        public int expires_in { get; set; }
        public string TokenType { get; set; }
        public string RefreshToken { get; set; }
        public bool IsValid { get; set; }
    }
}
