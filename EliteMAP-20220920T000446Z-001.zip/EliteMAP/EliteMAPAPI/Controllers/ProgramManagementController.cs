﻿using BusinessLayer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
//using System.Web.Http;

namespace SampleAPI.Controllers
{
    public class ProgramManagementController : ControllerBase
    {
        private EliteMAPBL EMAPBL = new EliteMAPBL();

        [HttpGet]
        [Route("L42Programs")]
        public JSONResponse<List<Programs>> L42Programs()
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.Programs, "Request Received For Programs");
            var response = new JSONResponse<List<Programs>>();

            try
            {

                // response.SetContent(ll);
                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.Programs, "Request Completed For Programs");
                response = EMAPBL.GetL42Programs();
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<List<Programs>> errorResponse = new JSONResponse<List<Programs>>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }

        [HttpGet]
        [Route("Programs")]
        public JSONResponse<List<Programs>> Programs()
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.Programs, "Request Received For Programs");
            var response = new JSONResponse<List<Programs>>();

            try
            {

                // response.SetContent(ll);
                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.Programs, "Request Completed For Programs");
                response = EMAPBL.GetAllPrograms();
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<List<Programs>> errorResponse = new JSONResponse<List<Programs>>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }

        [HttpPost]
        [Route("Program/Add")]
        public JSONResponse<bool> addProgram([FromBody] ProgramCreateReq request)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Received For AttributeList");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.AddProgram(request));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpPost]
        [Route("Program/Update")]
        public JSONResponse<bool> UpdateProgramDetails([FromBody] ProgramCreateReq request)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Received For AttributeList");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.UpdateProgramDetailById(request));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpGet]
        [Route("Program/Dashboard")]
        public JSONResponse<ProgramsDashBoard> ProgramDashboard(string Name, string Type, int PageNo, int PageSize)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Received For AttributeList");
            var response = new JSONResponse<ProgramsDashBoard>();

            try
            {
                response = (EMAPBL.GetProgramDashBoard(Name, Type, PageNo, PageSize));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Completed For AttributeList");
                Response.Headers.Add("Access-Control-Allow-Origin", "*");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<ProgramsDashBoard> errorResponse = new JSONResponse<ProgramsDashBoard>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpGet]
        [Route("Program/Details/{ProgramId}")]
        public JSONResponse<ProgramDetail> ProgramDashboard(string ProgramId)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Received For AttributeList");
            var response = new JSONResponse<ProgramDetail>();

            try
            {
                response = (EMAPBL.GetProgramDetailById(ProgramId));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AttributeList, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<ProgramDetail> errorResponse = new JSONResponse<ProgramDetail>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }


    }
}
