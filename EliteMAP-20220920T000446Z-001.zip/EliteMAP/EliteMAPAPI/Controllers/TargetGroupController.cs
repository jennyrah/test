﻿using BusinessLayer;
using EliteMAPService;
using LRAS.Brix.Core.Web;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
//using System.Web.Http;
using System.IO;
using System.Linq;

namespace SampleAPI.Controllers
{

    public class TargetGroupController : ControllerBase
    {
        //  private ILogger _logger = new NLogStore().GetLogger("nLogFileLogger");
        private EliteMAPBL EMAPBL = new EliteMAPBL();


        private readonly ILogger<TargetGroupController> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public TargetGroupController(IWebHostEnvironment webHostEnvironment, ILogger<TargetGroupController> logger)
        {
            _webHostEnvironment = webHostEnvironment;
            _logger = logger;
        }
        [HttpGet]
        [Route("{Type}/TargetGroupNames")]
        public JSONResponse<List<TGNameList>> TargetGroupNames(string Type)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TargetGroupNames, "Request Received For TargetGroupNames");
            var response = new JSONResponse<List<TGNameList>>();

            try
            {
                response = (EMAPBL.GetTGNames(Type));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TargetGroupNames, "Request Completed For TargetGroupNames");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.TargetGroupNames, ex.Message, ex);
                JSONResponse<List<TGNameList>> errorResponse = new JSONResponse<List<TGNameList>>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                // response=(errorResponse);
                return errorResponse;
            }


        }
        [HttpGet]

        [Route("STD")]
        public JSONResponse<STDDashBoard> STD(string Name, string Code, int PageNo, int PageSize, string ProgramId, int Status)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.STD, "Request Received For STD");
            var response = new JSONResponse<STDDashBoard>();

            try
            {
                response = (EMAPBL.STD(Name, Code, PageNo, PageSize, ProgramId, Status));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.STD, "Request Completed For STD");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.STD, ex.Message, ex);
                JSONResponse<STDDashBoard> errorResponse = new JSONResponse<STDDashBoard>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }
        [HttpGet]

        [Route("UCG")]
        public JSONResponse<UCGDashBoard> UCG(string Name, string Code, int PageNo, int PageSize, string ProgramId, int Status)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.UCG, "Request Received For UCG");
            var response = new JSONResponse<UCGDashBoard>();

            try
            {
                response = (EMAPBL.UCG(Name, Code, PageNo, PageSize, ProgramId, Status));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.UCG, "Request Completed For UCG");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.UCG, ex.Message, ex);
                JSONResponse<UCGDashBoard> errorResponse = new JSONResponse<UCGDashBoard>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //  response=(errorResponse);
                return errorResponse;
            }
            //var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            //var data = eliteMAPService.GetUCGRecordsAsync(Name, Code).Result;
            //return data;

        }

        [HttpGet]

        [Route("POC")]
        public JSONResponse<POCDashBoard> POC(string Name, string Code, int PageNo, int PageSize, string ProgramId, int Status)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.POC, "Request Received For POC");
            var response = new JSONResponse<POCDashBoard>();

            try
            {
                response = (EMAPBL.POC(Name, Code, PageNo, PageSize, ProgramId, Status));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.POC, "Request Completed For POC");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.POC, ex.Message, ex);
                JSONResponse<POCDashBoard> errorResponse = new JSONResponse<POCDashBoard>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                // response=(errorResponse);
                return response;
            }
        }

        [HttpGet]
        [Route("TGDetails/{TGId}")]
        public JSONResponse<TGDetailsResponse> TGDetails(string TGId)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TGDetails, "Request Received For TGDetails");
            var response = new JSONResponse<TGDetailsResponse>();

            try
            {
                response = (EMAPBL.GetTGDetailsById(TGId));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TGDetails, "Request Completed For TGDetails");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.TGDetails, ex.Message, ex);
                JSONResponse<TGDetailsResponse> errorResponse = new JSONResponse<TGDetailsResponse>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }

        }

        [HttpPost]
        [Route("STD/Add")]

        public JSONResponse<bool> AddSTD([FromForm] DataContract.AddTG request)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AddSTDTargetGroup, "Request Received For AddSTDTargetGroup");
            TargetGroupReq targetGroupReq = JsonConvert.DeserializeObject<TargetGroupReq>(request.tgrequest);
            var response = new JSONResponse<bool>();
            try
            {


                if (targetGroupReq.Type.Equals("file"))
                {
                    string wwwPath = _webHostEnvironment.WebRootPath;
                    string contentPath = _webHostEnvironment.ContentRootPath;

                    string path = Path.Combine(_webHostEnvironment.WebRootPath, "TGFiles");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    string fileName = "STD_" + DateTime.Now.ToString("yyyyMMddTHHmmss") + "_" + request.file.FileName;
                    using (FileStream stream = new FileStream(Path.Combine(path, fileName), FileMode.Create))
                    {
                        request.file.CopyTo(stream);
                    }



                    string fullPath = path + "\\" + fileName;
                    string ReadCSV = "";


                    FileStream fileStream = new FileStream(fullPath, FileMode.Open);
                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        ReadCSV = reader.ReadToEnd().Replace("\r", "");
                    }

                    var usersList = ReadCSV.Split("\n")
                                               .Skip(1).Where(x => !string.IsNullOrEmpty(x))
                                               .Select(v => FromCsv(v))
                                               .ToList();
                    List<TGUser> users = new List<TGUser>();
                    foreach (var item in usersList)
                    {
                        users.Add(new TGUser
                        {
                            UserId = item.UserId,
                            EmailId = item.EmailId,
                            MobileNo = item.MobileNo
                        });
                    }

                    targetGroupReq.FileDetails.users = users;
                    targetGroupReq.FileDetails.FileName = fileName;
                    targetGroupReq.FileDetails.FilePath = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}{HttpContext.Request.PathBase}" + "\\TGFiles\\" + fileName;
                }


                response = (EMAPBL.AddSTDTargetGroup(targetGroupReq));


                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AddPOCTargetGroup, "Request Completed For AddPOCTargetGroup");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.AddSTDTargetGroup, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        public static TGUser FromCsv(string csvLine)
        {
            TGUser user = new TGUser();
            if (!string.IsNullOrEmpty(csvLine))
            {
                string[] values = csvLine.Split(',');
                user.UserId = Convert.ToString(values[0]);
                user.EmailId = Convert.ToString(values[1]);
                user.MobileNo = Convert.ToString(values[2]).Replace("\r", "");
            }
            return user;

        }

        [HttpPost]
        [Route("UCG/Add")]
        public JSONResponse<bool> AddUCGTargetGroup([FromForm] DataContract.AddTG request)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AddUCGTargetGroup, "Request Received For AddUCGTargetGroup");
            var response = new JSONResponse<bool>();
            try
            {
                UCGTargetGroupReq targetGroupReq = JsonConvert.DeserializeObject<UCGTargetGroupReq>(request.tgrequest);
                if (targetGroupReq.Type.Equals("file"))
                {
                    string wwwPath = _webHostEnvironment.WebRootPath;
                    string contentPath = _webHostEnvironment.ContentRootPath;

                    string path = Path.Combine(_webHostEnvironment.WebRootPath, "TGFiles");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    string fileName = "STD_" + DateTime.Now.ToString("yyyyMMddTHHmmss") + "_" + request.file.FileName;
                    using (FileStream stream = new FileStream(Path.Combine(path, fileName), FileMode.Create))
                    {
                        request.file.CopyTo(stream);
                    }


                    string ReadCSV = "";
                    string fullPath = path + "\\" + fileName;
                    FileStream fileStream = new FileStream(fullPath, FileMode.Open);
                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        ReadCSV = reader.ReadToEnd().Replace("\r", "");
                    }

                    var usersList = ReadCSV.Split("\n")
                                               .Skip(1).Where(x => !string.IsNullOrEmpty(x))
                                               .Select(v => FromCsv(v))
                                               .ToList();
                    List<TGUser> users = new List<TGUser>();
                    foreach (var item in usersList)
                    {
                        users.Add(new TGUser
                        {
                            UserId = item.UserId,
                            EmailId = item.EmailId,
                            MobileNo = item.MobileNo
                        });
                    }

                    targetGroupReq.FileDetails.users = users;
                    targetGroupReq.FileDetails.FileName = fileName;
                    targetGroupReq.FileDetails.FilePath = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}{HttpContext.Request.PathBase}" + "\\TGFiles\\" + fileName;
                }

                response = (EMAPBL.AddUCGTargetGroup(targetGroupReq));
                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AddUCGTargetGroup, "Request Completed For AddUCGTargetGroup");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.AddUCGTargetGroup, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }
        }

        [HttpPost]
        [Route("POC/Add")]
        public JSONResponse<bool> AddPOCTargetGroup([FromForm] DataContract.AddTG request)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AddPOCTargetGroup, "Request Received For AddPOCTargetGroup");
            var response = new JSONResponse<bool>();
            try
            {
                POCTargetGroupReq targetGroupReq = JsonConvert.DeserializeObject<POCTargetGroupReq>(request.tgrequest);
                if (targetGroupReq.Type.Equals("file"))
                {
                    string wwwPath = _webHostEnvironment.WebRootPath;
                    string contentPath = _webHostEnvironment.ContentRootPath;

                    string path = Path.Combine(_webHostEnvironment.WebRootPath, "TGFiles");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }

                    string fileName = "STD_" + DateTime.Now.ToString("yyyyMMddTHHmmss") + "_" + request.file.FileName;
                    using (FileStream stream = new FileStream(Path.Combine(path, fileName), FileMode.Create))
                    {
                        request.file.CopyTo(stream);
                    }

                    string ReadCSV = "";
                    string fullPath = path + "\\" + fileName;
                    FileStream fileStream = new FileStream(fullPath, FileMode.Open);
                    using (StreamReader reader = new StreamReader(fileStream))
                    {
                        ReadCSV = reader.ReadToEnd().Replace("\r", "");
                    }

                    var usersList = ReadCSV.Split("\n")
                                               .Skip(1).Where(x => !string.IsNullOrEmpty(x))
                                               .Select(v => FromCsv(v))
                                               .ToList();
                    List<TGUser> users = new List<TGUser>();
                    foreach (var item in usersList)
                    {
                        users.Add(new TGUser
                        {
                            UserId = item.UserId,
                            EmailId = item.EmailId,
                            MobileNo = item.MobileNo
                        });
                    }

                    targetGroupReq.FileDetails.users = users;
                    targetGroupReq.FileDetails.FileName = fileName;
                    targetGroupReq.FileDetails.FilePath = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}{HttpContext.Request.PathBase}" + "\\TGFiles\\" + fileName;
                }

                response = (EMAPBL.AddPOCTargetGroup(targetGroupReq));
                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.AddPOCTargetGroup, "Request Completed For AddPOCTargetGroup");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.AddPOCTargetGroup, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }
        }

        [HttpPost]
        [Route("CalculateMember")]
        public JSONResponse<MemberCountResp> CalculateMember([FromBody] MemberCountReq request)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.CalculateMember, "Request Received For CalculateMember");
            var response = new JSONResponse<MemberCountResp>();

            try
            {
                response = (EMAPBL.CalculateMember(request));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.CalculateMember, "Request Completed For CalculateMember");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.CalculateMember, ex.Message, ex);
                JSONResponse<MemberCountResp> errorResponse = new JSONResponse<MemberCountResp>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }

        }

        [HttpGet]
        [Route("TGMemberCount/{TGId}")]
        public JSONResponse<List<MemberCountByTGId>> TGMemberCount(string TGId)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TGMemberCount, "Request Received For TGDetails");
            var response = new JSONResponse<List<MemberCountByTGId>>();

            try
            {
                response = (EMAPBL.GetMemberCountByTGId(TGId));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TGMemberCount, "Request Completed For TGDetails");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.TGMemberCount, ex.Message, ex);
                JSONResponse<List<MemberCountByTGId>> errorResponse = new JSONResponse<List<MemberCountByTGId>>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }

        }
        [HttpPost]
        [Route("STD/Update")]
        public JSONResponse<bool> UpdateTG([FromBody] TargetGroupReq targetGroupReq)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TGMemberCount, "Request Received For TGDetails");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.UpdateTG(targetGroupReq));

                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.TGMemberCount, "Request Completed For TGDetails");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.TGMemberCount, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }

        }

        [HttpPost]
        [Route("UpdateStatus")]
        public JSONResponse<bool> UpdateStatus([FromBody] StatusChangeRequest approvalIds)
        {
            LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.StatusChange, "Request Received For SendForApproval");
            var response = new JSONResponse<bool>();
            try
            {
                response = (EMAPBL.UpdateStatus(approvalIds));
                LogHandler.Info(ClassNameConstraints.TGController, MethodNameConstraints.StatusChange, "Request Completed For SendForApproval");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TGController, MethodNameConstraints.StatusChange, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }
        }

    }
}
