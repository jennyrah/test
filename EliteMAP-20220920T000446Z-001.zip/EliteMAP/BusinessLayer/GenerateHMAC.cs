﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Web;


namespace BusinessLayer
{
    class GenerateHMAC
    {
        public string Generate(string clientId, string clientKey, string body, string methodType, string requestUri)
        {
            var hmacSignGenerator = new HmacSignGenerator();
            var sign = hmacSignGenerator.GenerateSign(clientId, clientKey, methodType,
                HttpUtility.UrlEncode(requestUri.ToLower()), body);
            return sign;
        }

    }
    public class HmacSignGenerator
    {
        public string GenerateSign(string clientId,
                                 string clientKey,
                                 string requestHttpMethod,
                                 string requestUri,
                                 string contentStr)
        {
            string requestContentBase64String = string.Empty;

            //Calculate UNIX time
            DateTime epochStart = new DateTime(1970, 01, 01, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan timeSpan = DateTime.UtcNow - epochStart;
            string requestTimeStamp = Convert.ToUInt64(timeSpan.TotalSeconds).ToString();

            //create random nonce for each request
            string nonce = Guid.NewGuid().ToString("N");

            //Checking if the request contains body, usually will be null wiht HTTP GET and DELETE
            if (!string.IsNullOrEmpty(contentStr))
            {
                byte[] content = Encoding.UTF8.GetBytes(contentStr);
                MD5 md5 = MD5.Create();
                //Hashing the request body, any change in request body will result in different hash, we'll incure message integrity
                byte[] requestContentHash = md5.ComputeHash(content);
                requestContentBase64String = Convert.ToBase64String(requestContentHash);
            }

            //Creating the raw signature string
            string signatureRawData = string.Format("{0}{1}{2}{3}{4}{5}", clientId, requestHttpMethod, requestUri, requestTimeStamp, nonce, requestContentBase64String);
            Console.WriteLine("nonce {0}", nonce);
            Console.WriteLine("timestamp {0}", requestTimeStamp);
            Console.WriteLine("content {0}", requestContentBase64String);
            Console.WriteLine("data {0}", signatureRawData);

            var secretKeyByteArray = Encoding.UTF8.GetBytes(clientKey);
            byte[] signature = Encoding.UTF8.GetBytes(signatureRawData);

            using (var hmac = new HMACSHA256(secretKeyByteArray))
            {
                byte[] signatureBytes = hmac.ComputeHash(signature);
                string requestSignatureBase64String = Convert.ToBase64String(signatureBytes);
                //Setting the values in the Authorization header using custom scheme (amx)
                var x = string.Format("{0}:{1}:{2}:{3}", clientKey, requestSignatureBase64String, nonce, requestTimeStamp);
                return x;
            }
        }
    }

}
