﻿using AutoMapper;
using DataContract;
using LRAS.EliteMAP.DataContract;
using System;

namespace BusinessLayer
{
    public class DTOMapping
    {
        public static bool IsMapped { get; set; }
        public static void Mapp()
        {
            if (!IsMapped)
                Mapper.Initialize(cfg =>
                {
                    cfg.CreateMap<FileDetail, LRAS.EliteMAP.DataContract.FileDetail>().ReverseMap();
                    cfg.CreateMap<Programs, LRAS.EliteMAP.DataContract.Programs>().ReverseMap();
                    cfg.CreateMap<TGUser, LRAS.EliteMAP.DataContract.TGUser>().ReverseMap();
                    cfg.CreateMap<Program, LRAS.EliteMAP.DataContract.Program>().ReverseMap();
                    cfg.CreateMap<STDDashBoard, LRAS.EliteMAP.DataContract.STDDashBoard>().ReverseMap();
                    cfg.CreateMap<TGResponse, LRAS.EliteMAP.DataContract.TGResponse>().ReverseMap();
                    cfg.CreateMap<UCGDashBoard, LRAS.EliteMAP.DataContract.UCGDashBoard>().ReverseMap();
                    cfg.CreateMap<POCDashBoard, LRAS.EliteMAP.DataContract.POCDashBoard>().ReverseMap();
                    cfg.CreateMap<ProgramsDashBoard, LRAS.EliteMAP.DataContract.ProgramsDashBoard>().ReverseMap();
                    cfg.CreateMap<TemplateRecords, LRAS.EliteMAP.DataContract.TemplateRecords>().ReverseMap();
                    cfg.CreateMap<AttributeRecords, LRAS.EliteMAP.DataContract.AttributeRecords>().ReverseMap();
                    cfg.CreateMap<TGNameList, LRAS.EliteMAP.DataContract.TGNameList>().ReverseMap();
                    cfg.CreateMap<Attribute, LRAS.EliteMAP.DataContract.AttributeList>().ReverseMap();
                    cfg.CreateMap<Record, LRAS.EliteMAP.DataContract.Record>().ReverseMap();
                    cfg.CreateMap<TGDetailsResponse, LRAS.EliteMAP.DataContract.TGDetailsResponse>().ReverseMap();
                    cfg.CreateMap<AttributeOperationList, LRAS.EliteMAP.DataContract.AttributeOperationList>().ReverseMap();
                    cfg.CreateMap<AttributeList, LRAS.EliteMAP.DataContract.AttributeList>().ReverseMap();
                    cfg.CreateMap<OperationList, LRAS.EliteMAP.DataContract.OperationList>().ReverseMap();
                    cfg.CreateMap<POCResponse, LRAS.EliteMAP.DataContract.POCResponse>().ReverseMap();
                    cfg.CreateMap<ProgramListForTGDetail, LRAS.EliteMAP.DataContract.ProgramListForTGDetail>().ReverseMap();
                    cfg.CreateMap<ProgramDetail, LRAS.EliteMAP.DataContract.ProgramDetail>().ReverseMap();
                    cfg.CreateMap<RecordsList, LRAS.EliteMAP.DataContract.RecordsList>().ReverseMap();
                    cfg.CreateMap<Attributes, LRAS.EliteMAP.DataContract.Attributes>().ReverseMap();
                    cfg.CreateMap<TemplateDetail, LRAS.EliteMAP.DataContract.TemplateDetail>().ReverseMap();
                    cfg.CreateMap<Templates, LRAS.EliteMAP.DataContract.Templates>().ReverseMap();
                    cfg.CreateMap<ProgramCreateReq, LRAS.EliteMAP.DataContract.ProgramCreateReq>().ReverseMap();
                    cfg.CreateMap<AddAttributeReq, LRAS.EliteMAP.DataContract.AddAttributeReq>().ReverseMap();
                    cfg.CreateMap<AddTemplateReq, LRAS.EliteMAP.DataContract.AddTemplateReq>().ReverseMap();
                    cfg.CreateMap<TargetGroupReq, LRAS.EliteMAP.DataContract.TargetGroupReq>().ReverseMap();
                    cfg.CreateMap<AttributeOperations, LRAS.EliteMAP.DataContract.AttributeOperations>().ReverseMap();
                    cfg.CreateMap<MemberCountReq, LRAS.EliteMAP.DataContract.MemberCountReq>().ReverseMap();
                    cfg.CreateMap<ProgramsForTG, LRAS.EliteMAP.DataContract.ProgramsForTG>().ReverseMap();
                    cfg.CreateMap<AttributeOperationsForTG, LRAS.EliteMAP.DataContract.AttributeOperationsForTG>().ReverseMap();
                    cfg.CreateMap<ProgramsForPOC, LRAS.EliteMAP.DataContract.ProgramsForPOC>().ReverseMap();
                    cfg.CreateMap<MapTemplates, LRAS.EliteMAP.DataContract.MapTemplates>().ReverseMap();
                    cfg.CreateMap<MapAttributes, LRAS.EliteMAP.DataContract.MapAttributes>().ReverseMap();
                    cfg.CreateMap<UCGTargetGroupReq, LRAS.EliteMAP.DataContract.UCGTargetGroupReq>().ReverseMap();
                    cfg.CreateMap<POCTargetGroupReq, LRAS.EliteMAP.DataContract.POCTargetGroupReq>().ReverseMap();
                    cfg.CreateMap<MemberCountResp, LRAS.EliteMAP.DataContract.MemberCountResp>().ReverseMap();
                    cfg.CreateMap<MemberCountByTGId, LRAS.EliteMAP.DataContract.MemberCountByTGId>().ReverseMap();
                    cfg.CreateMap<Tags, LRAS.EliteMAP.DataContract.Tags>().ReverseMap();
                    cfg.CreateMap<SMSCampaignDashBoard, LRAS.EliteMAP.DataContract.SMSCampaignDashBoard>().ReverseMap();
                    cfg.CreateMap<EmailCampaignDashBoard, LRAS.EliteMAP.DataContract.EmailCampaignDashBoard>().ReverseMap();
                    cfg.CreateMap<EmailCampaign, LRAS.EliteMAP.DataContract.EmailCampaign>().ReverseMap();
                    cfg.CreateMap<SMSCampaign, LRAS.EliteMAP.DataContract.SMSCampaign>().ReverseMap();
                    cfg.CreateMap<StatusChangeRequest, LRAS.EliteMAP.DataContract.StatusChangeRequest>().ReverseMap();
                    cfg.CreateMap<CampaignStatusChangeRequest, LRAS.EliteMAP.DataContract.CampaignStatusChangeRequest>().ReverseMap();
                    cfg.CreateMap<CreateCampaignRequest, LRAS.EliteMAP.DataContract.CreateCampaignRequest>().ReverseMap();
                    cfg.CreateMap<ProgramConfiguration, LRAS.EliteMAP.DataContract.ProgramConfiguration>().ReverseMap();
                    cfg.CreateMap<ProgramsData, LRAS.EliteMAP.DataContract.Programs>()
                    .ForMember(o => o.Id, b => b.MapFrom(z => z.Id))
                    .ForMember(o => o.ProgramName, b => b.MapFrom(z => z.Name)).ReverseMap();
                    IsMapped = true;
                    cfg.CreateMap<CreateSMSCampaign, LRAS.EliteMAP.DataContract.CreateSMSCampaign>().ReverseMap();
                    cfg.CreateMap<SMSConfiguration, LRAS.EliteMAP.DataContract.SMSConfiguration>().ReverseMap();

                });
        }
    }
}
