/*eslint-env browser*/

var i;
var hash = "";
for (i = 0; i <= 6; i += 1) {
    window.console.log(hash += "#");
}