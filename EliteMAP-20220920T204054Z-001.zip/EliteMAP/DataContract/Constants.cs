﻿namespace DataContract
{
    public class Constants
    {
        public static readonly string EliteGetAllProgramsAPI = "http://192.168.32.79/LRAS.ConfigurationAPI/V2/Program/List?Status=All";
        public static readonly string ApplicationId = "565b009b-ddd5-11e8-b030-00155dc9974a";
        public static readonly string UserIp = "192.168.32.92";
        public static readonly string UserAgent = "Instore Panel";
        public static readonly string ClientId = "12";
        public static readonly string ClientKey = "portalinternal";
        public static readonly string MemberModuleId = "fa69d163-ba2c-11e7-8376-00155d0a0867";
        public static readonly string JsonContentType = "application/json";
        public static readonly int TimeOut = 300;
        public static readonly string TokenDeURL = "https://qatokenservice.loylty.com/identity/connect/token";
        public static readonly string grant_type = "password";
        public static readonly string username = "shushil.anand";
        public static readonly string password = "loylty@123";
        public static readonly string DataEncryptionKey = "597133743677397A24432646294A404D";
    }
}
