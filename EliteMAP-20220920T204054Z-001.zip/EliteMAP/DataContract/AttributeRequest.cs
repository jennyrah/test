﻿using System;

namespace DataContract
{
    public class AttributeRequest
    {
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public string DataType { get; set; }

        public string DisplayName { get; set; }

        public string MaxLength { get; set; }

        public string MinLength { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }


    }
}
