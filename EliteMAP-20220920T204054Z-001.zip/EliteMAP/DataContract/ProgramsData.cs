﻿namespace DataContract
{
    public class ProgramsData
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
