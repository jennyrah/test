﻿using Microsoft.AspNetCore.Http;

namespace DataContract
{
    public class AddTG
    {
        public IFormFile file { get; set; }

        public string tgrequest { get; set; }
    }

}
