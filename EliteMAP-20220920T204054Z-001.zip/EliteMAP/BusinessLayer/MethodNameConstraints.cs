﻿namespace BusinessLayer
{
    public class MethodNameConstraints
    {
        public const string Programs = "Programs";
        public const string TargetGroupNames = "TargetGroupNames";
        public const string STD = "STDRecords";
        public const string UCG = "UCGRecords";
        public const string POC = "POCRecords";
        public const string AttributeList = "GetAttributes";
        public const string TGDetails = "TGDetails";
        public const string AddAttribute = "AddAttribute";
        public const string UpdateAttribute = "UpdateAttribute";
        public const string AttributeRecords = "AttributeRecords";
        public const string AttributeDetails = "AttributeDetails";
        public const string AddTemplate = "AddTemplate";
        public const string UpdateTemplate = "UpdateTemplate";
        public const string TemplateRecords = "TemplateRecords";
        public const string TemplateDetails = "TemplateDetails";
        public const string AllAttributes = "AllAttributes";
        public const string AllTemplates = "AllTemplates";
        public const string AddSTDTargetGroup = "AddSTDTargetGroup";
        public const string AddUCGTargetGroup = "AddUCGTargetGroup";
        public const string AddPOCTargetGroup = "AddPOCTargetGroup";
        public const string SendForApproval = "SendForApproval";
        public const string ApproveRecords = "ApproveRecords";
        public const string RejectRecords = "RejectRecords";
        public const string Email = "Email";
        public const string SMS = "SMS";
        public const string Tags = "Tags";
        public const string MAPAttributes = "MAPAttributes";
        public const string MAPTemplates = "MAPTemplates";
        public const string CalculateMember = "CalculateMember";
        public const string TGMemberCount = "TGMemberCount";
        public const string StatusChange = "StatusChange";

    }
}
