﻿using LRAS.Brix.Core.Service;
using LRAS.Brix.Core.Web;
using LRAS.Brix.Logging;
using System;

namespace BusinessLayer
{
    public class LogHandler
    {
        public const string ChannelName = "WebAPI";
        public const string ModuleName = "EliteMap";

        private static readonly ILogger Logger = new NLogStore().GetLogger("nLogFileLogger");

        public static void Info(string className, string methodName, string message)
        {
            //Logger.Info(ChannelName, ModuleName, className, methodName, message, String.Empty, String.Empty, String.Empty);
        }

        public static void Info(string className, string methodName, string message, string sessionId, string uniqueId, string ipAddress)
        {
            //Logger.Info(ChannelName, ModuleName, className, methodName, message, sessionId, uniqueId, ipAddress);
        }

        public static void Info<T>(string className, string methodName, string message, BaseReturn<T> baseReturn)
        {
            //Logger.Info(ChannelName, ModuleName, className, methodName, message, baseReturn);
        }

        public static void Info<T>(string className, string methodName, string message, JSONResponse<T> apiresponse)
        {
            //Logger.Info(ChannelName, ModuleName, className, methodName, message, apiresponse);
        }

        public static void Error(string className, string methodName, string message, Exception exception)
        {
            //Logger.Error(channelName: ChannelName, moduleName: ModuleName, pageName: className, methodName: methodName, exception: exception);
        }

        public static void Error<T>(string className, string methodName, string message, JSONResponse<T> jsonResponse)
        {
            //Logger.Info(ChannelName, ModuleName, className, methodName, message, jsonResponse);
        }

        public static void Error(string className, string methodName, string message, string sessionId, string u)
        {
            //Logger.Info(ChannelName, ModuleName, className, methodName, message, String.Empty, String.Empty, String.Empty);
        }
    }
}
