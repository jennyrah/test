﻿using AutoMapper;
using LRAS.EliteMAP.DataContract;
using LRAS.Brix.Core.Web;
using LRAS.Brix.Core.Web.Extension;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net;
using Newtonsoft.Json;
using DataContract;
using System.Diagnostics;
using System.Reflection;
using WebRequest = LRAS.Brix.Core.Web.HttpModule.WebRequest;
using LRAS.Elite.BusinessLibrary;

namespace BusinessLayer
{
    public class EliteMAPBL
    {
        public EliteMAPBL()
        {
            DTOMapping.Mapp();
        }

        private static string token = string.Empty;
        private static DateTime _expiredTime = new DateTime();
        private static readonly object Instancelock = new object();
        private static string _BearerToken = string.Empty;
        public static Stopwatch tokenWatch = new Stopwatch();

        public static string GetToken
        {
            get
            {
                lock (Instancelock)
                {
                    DateTime currentTime = DateTime.Now;
                    if (string.IsNullOrEmpty(token) || (currentTime > _expiredTime))
                    {
                        token = EliteMAPBL.GetBaererTokenAsync(ref _expiredTime);
                    }
                    return token;
                }
            }
        }

        public static string GetBaererTokenAsync(ref DateTime _expiredTime)
        {
            try
            {
                Stopwatch stopWatch = new Stopwatch();
                stopWatch.Start();

                var url = Constants.TokenDeURL;

                var requestPayload = new Dictionary<string, string>();
                requestPayload.Add("username", Constants.username);
                requestPayload.Add("password", Constants.password);
                requestPayload.Add("grant_type", "password");
                requestPayload.Add("client_id", Constants.ClientKey);
                var methodBase = MethodBase.GetCurrentMethod();
                var client = new HttpClient();
                var a = new FormUrlEncodedContent(requestPayload);
                var req = new HttpRequestMessage(HttpMethod.Post, url) { Content = new FormUrlEncodedContent(requestPayload) };
                var webResponse = client.SendAsync(req).Result;
                if (webResponse.StatusCode == HttpStatusCode.OK)
                {
                    var response = webResponse.Content.ReadAsStringAsync().Result;
                    var jsonResponse = JsonConvert.DeserializeObject<AuthTokenResponse>(response);
                    _BearerToken = jsonResponse.access_token;
                    _expiredTime = DateTime.Now.AddSeconds(jsonResponse.expires_in);
                    tokenWatch.Start();
                }
                else
                {
                    return string.Empty;
                }
                stopWatch.Stop();
            }
            catch (Exception Ex) { }
            return _BearerToken;
        }

        private static Dictionary<string, string> GetHeaders(string lrSignAuth, string ModuleId, string programId)
        {
            var headers = new Dictionary<string, string>
                {
                    {"Authorization", "Bearer " + EliteMAPBL.GetToken},
                    {"ModuleId", ModuleId},
                    {"ApplicationId", Constants.ApplicationId},
                    {"UserIp", Constants.UserIp},
                    {"UserAgent", Constants.UserAgent},
                    {"sign_auth", lrSignAuth},
                    {"client_id",Constants.ClientId}
                };
            if (!string.IsNullOrEmpty(programId))
                headers.Add("ProgramId", programId);

            return headers;
        }
        public JSONResponse<List<Programs>> GetAllPrograms()
        {

            JSONResponse<List<Programs>> response = new JSONResponse<List<Programs>>();
            List<Programs> Objresponse = new List<Programs>();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetProgramListAsync().Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<List<Programs>>(res.Data.ProgramList);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<List<TGNameList>> GetTGNames(string type)
        {
            JSONResponse<List<TGNameList>> response = new JSONResponse<List<TGNameList>>();
            List<TGNameList> Objresponse = new List<TGNameList>();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetTGNameListByTypeAsync(type).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<List<TGNameList>>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<STDDashBoard> STD(string Name, string Code, int PageNo, int PageSize, string ProgramId, int Status)
        {
            JSONResponse<STDDashBoard> response = new JSONResponse<STDDashBoard>();
            STDDashBoard Objresponse = new STDDashBoard();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetSTDRecordsAsync(new EliteMAPService.TGSearchRequest()
            {
                Name = Name,
                Code = Code,
                PageNumber = PageNo,
                PageSize = PageSize,
                Status = Status,
                ProgramId = ProgramId
            }).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<STDDashBoard>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<UCGDashBoard> UCG(string Name, string Code, int PageNo, int PageSize, string ProgramId, int Status)
        {
            JSONResponse<UCGDashBoard> response = new JSONResponse<UCGDashBoard>();
            UCGDashBoard Objresponse = new UCGDashBoard();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetUCGRecordsAsync(new EliteMAPService.TGSearchRequest()
            {
                Name = Name,
                Code = Code,
                PageNumber = PageNo,
                PageSize = PageSize,
                Status = Status,
                ProgramId = ProgramId
            }).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<UCGDashBoard>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<POCDashBoard> POC(string Name, string Code, int PageNo, int PageSize, string ProgramId, int Status)
        {
            JSONResponse<POCDashBoard> response = new JSONResponse<POCDashBoard>();
            POCDashBoard Objresponse = new POCDashBoard();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetPOCRecordsAsync(new EliteMAPService.TGSearchRequest()
            {
                Name = Name,
                Code = Code,
                PageNumber = PageNo,
                PageSize = PageSize,
                Status = Status
            }).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<POCDashBoard>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<List<AttributeList>> GetAttributes(string ProgramId)
        {
            JSONResponse<List<AttributeList>> response = new JSONResponse<List<AttributeList>>();
            List<AttributeList> Objresponse = new List<AttributeList>();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetAttributesAndOperationByProgramIdAsync(ProgramId).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<List<AttributeList>>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<TGDetailsResponse> GetTGDetailsById(string TGId)
        {
            JSONResponse<TGDetailsResponse> response = new JSONResponse<TGDetailsResponse>();
            TGDetailsResponse Objresponse = new TGDetailsResponse();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetTGDetailsByIdAsync(TGId).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<TGDetailsResponse>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> AddAttribute(AddAttributeReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.AddAttributeAsync(Mapper.Map<EliteMAPService.AddAttributeReq>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> AddProgram(ProgramCreateReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.CreateProgramAsync(Mapper.Map<EliteMAPService.ProgramCreateReq>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<ProgramsDashBoard> GetProgramDashBoard(string Name, string Type, int pageNo, int pageSize)
        {
            JSONResponse<ProgramsDashBoard> response = new JSONResponse<ProgramsDashBoard>();
            ProgramsDashBoard Objresponse = new ProgramsDashBoard();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetProgramsDashboardAsync(new EliteMAPService.ProgramSearchReq() { Name = Name, Type = Type, PageNumber = pageNo, PageSize = pageSize }).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<ProgramsDashBoard>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<ProgramDetail> GetProgramDetailById(string ProgramId)
        {
            JSONResponse<ProgramDetail> response = new JSONResponse<ProgramDetail>();
            ProgramDetail Objresponse = new ProgramDetail();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetProgramDetailByIdAsync(ProgramId).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<ProgramDetail>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<RecordsList> GetAllTemplates(string Type, string ProgramId)
        {
            JSONResponse<RecordsList> response = new JSONResponse<RecordsList>();
            RecordsList Objresponse = new RecordsList();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetAllTemplatesAsync(Type, ProgramId).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<RecordsList>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<AttributeRecords> GetAttributeDashboard(string Name, string DisplayName, int PageNo, int PageSize)
        {
            JSONResponse<AttributeRecords> response = new JSONResponse<AttributeRecords>();
            AttributeRecords Objresponse = new AttributeRecords();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetAttributeRecordsAsync(new EliteMAPService.AttributeSearchRequest() { Name = Name, DisplayName = DisplayName, PageNumber = PageNo, PageSize = PageSize }).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<AttributeRecords>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<TemplateRecords> GetTemplateDashboard(string Name, string Type, int PageNo, int PageSize)
        {
            JSONResponse<TemplateRecords> response = new JSONResponse<TemplateRecords>();
            TemplateRecords Objresponse = new TemplateRecords();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetTemplateRecordsAsync(new EliteMAPService.TemplateSearchRequest() { Name = Name, Type = Type, PageNumber = PageNo, PageSize = PageSize }).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<TemplateRecords>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<Templates> GeTemplateDetailById(string TemplateId)
        {
            JSONResponse<Templates> response = new JSONResponse<Templates>();
            Templates Objresponse = new Templates();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetTemplateDetailByIdAsync(TemplateId).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<Templates>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<Attributes> GetAttributeDetailById(string AttribueId)
        {
            JSONResponse<Attributes> response = new JSONResponse<Attributes>();
            Attributes Objresponse = new Attributes();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetAtributeDetailByIdAsync(AttribueId).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<Attributes>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> UpdateAttributeDetailById(AddAttributeReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = false;
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.UpdateAttributeDetailByIdAsync(Mapper.Map<EliteMAPService.AddAttributeReq>(request)).Result;

            if (res.Success)
            {
                Objresponse = (res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> UpdateTemplateDetailById(AddTemplateReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = false;
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.UpdateTemplateDetailByIdAsync(Mapper.Map<EliteMAPService.AddTemplateReq>(request)).Result;

            if (res.Success)
            {
                Objresponse = (res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> AddTemplate(AddTemplateReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.AddTemplateAsync(Mapper.Map<EliteMAPService.AddTemplateReq>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<RecordsList> GetAllAttributes()
        {
            JSONResponse<RecordsList> response = new JSONResponse<RecordsList>();
            RecordsList Objresponse = new RecordsList();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetAllAttributesAsync().Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<RecordsList>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> MapTemplate(MapTemplates request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = false;
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.MapTemplateAsync(Mapper.Map<EliteMAPService.MapTemplates>(request)).Result;

            if (res.Success)
            {
                Objresponse = (res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> MapAttribute(MapAttributes request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = false;
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.MapAttributeAsync(Mapper.Map<EliteMAPService.MapAttributes>(request)).Result;

            if (res.Success)
            {
                Objresponse = (res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<bool> UpdateProgramDetailById(ProgramCreateReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = false;
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.UpdateProgramDetailByIdAsync(Mapper.Map<EliteMAPService.ProgramCreateReq>(request)).Result;

            if (res.Success)
            {
                Objresponse = (res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Records Found" : "No records found");
            return response;
        }
        public JSONResponse<List<Programs>> GetL42Programs()
        {
            JSONResponse<List<Programs>> response = new JSONResponse<List<Programs>>();
            List<ProgramsData> list = new List<ProgramsData>();
            var url = Constants.EliteGetAllProgramsAPI;
            var lrSignAuth = new GenerateHMAC().Generate(Constants.ClientId, Constants.ClientKey, "", "GET", url);
            Dictionary<string, string> headers = GetHeaders(lrSignAuth, Constants.MemberModuleId, "");

            var client = new HttpClient();
            var req = new HttpRequestMessage(HttpMethod.Get, url);
            string webResponse = "";
            Parallel.Invoke(() => webResponse = webResponse_(url, "GET", "", headers));
            webResponse = AESGCM.SimpleDecrypt(webResponse, Encoding.UTF8.GetBytes(Constants.DataEncryptionKey));
            ProgramsResponse jsonResponse = JsonConvert.DeserializeObject<ProgramsResponse>(webResponse);
            list = jsonResponse.Data;
            List<Programs> Objresponse = new List<Programs>();
            var dbprograms = GetAllPrograms();
            var programList = list.Where(x => dbprograms.Data.Any(y => y.Id != x.Id)).ToList();

            if (programList != null)
            {
                Objresponse = Mapper.Map<List<Programs>>(programList);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }

        public static string webResponse_(string url, string method, string body, Dictionary<string, string> headers)
        {
            return WebRequest.Create(url, method, body, headers, Constants.JsonContentType, Constants.TimeOut, true);
        }

        public JSONResponse<bool> AddSTDTargetGroup(TargetGroupReq targetGroupReq)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.AddSTDTargetGroupAsync(Mapper.Map<EliteMAPService.TargetGroupReq>(targetGroupReq)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "STD Target group created successfully" : "No records found");
            return response;
        }

        public JSONResponse<bool> AddUCGTargetGroup(UCGTargetGroupReq targetGroupReq)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.AddUCGTargetGroupAsync(Mapper.Map<EliteMAPService.UCGTargetGroupReq>(targetGroupReq)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "UCG Target group created successfully" : "No records found");
            return response;
        }

        public JSONResponse<bool> AddPOCTargetGroup(POCTargetGroupReq targetGroupReq)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.AddPOCTargetGroupAsync(Mapper.Map<EliteMAPService.POCTargetGroupReq>(targetGroupReq)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "POC Target group created successfully" : "No records found");
            return response;
        }

        public JSONResponse<EmailCampaignDashBoard> Email(string Name, string Status, DateTime startDate, DateTime endDate, int PageNo, int PageSize, string ProgramId)
        {
            JSONResponse<EmailCampaignDashBoard> response = new JSONResponse<EmailCampaignDashBoard>();
            EmailCampaignDashBoard Objresponse = new EmailCampaignDashBoard();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetEmailCampaignDashboardAsync(new EliteMAPService.EmailCampaignSearchReq() { Name = Name, Status = Status, StartDate = startDate, EndDate = endDate, PageNumber = PageNo, PageSize = PageSize, ProgramId = ProgramId }).Result;
            if (res.Success)
            {
                Objresponse = Mapper.Map<EmailCampaignDashBoard>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "records found " : "No records found");
            return response;
        }

        public JSONResponse<SMSCampaignDashBoard> SMS(string Name, string Status, DateTime startDate, DateTime endDate, int PageNo, int PageSize, string ProgramId)
        {
            JSONResponse<SMSCampaignDashBoard> response = new JSONResponse<SMSCampaignDashBoard>();
            SMSCampaignDashBoard Objresponse = new SMSCampaignDashBoard();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetSMSCampaignDashboardAsync(new EliteMAPService.SMSCampaignSearchReq() { Name = Name, Status = Status, StartDate = startDate, EndDate = endDate, PageNumber = PageNo, PageSize = PageSize, ProgramId = ProgramId }).Result;
            if (res.Success)
            {
                Objresponse = Mapper.Map<SMSCampaignDashBoard>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "records found" : "No records found");
            return response;
        }

        public JSONResponse<List<Tags>> GetAllTags(string Name)
        {
            JSONResponse<List<Tags>> response = new JSONResponse<List<Tags>>();
            List<Tags> Objresponse = new List<Tags>();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetTagsAsync(Name).Result;

            if (res.Success)
            {
                Objresponse = Mapper.Map<List<Tags>>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Records Found" : "No records found");
            return response;
        }

        public JSONResponse<MemberCountResp> CalculateMember(MemberCountReq memberCountReq)
        {
            JSONResponse<MemberCountResp> response = new JSONResponse<MemberCountResp>();
            MemberCountResp Objresponse = new MemberCountResp();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetMemberCountAsync(Mapper.Map<EliteMAPService.MemberCountReq>(memberCountReq)).Result;
            if (res.Success)
            {
                Objresponse = Mapper.Map<MemberCountResp>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "Member count got successfully" : "No records found");
            return response;
        }
        public JSONResponse<List<MemberCountByTGId>> GetMemberCountByTGId(string TGId)
        {
            JSONResponse<List<MemberCountByTGId>> response = new JSONResponse<List<MemberCountByTGId>>();
            List<MemberCountByTGId> Objresponse = new List<MemberCountByTGId>();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetMemberCountByTGIdAsync(TGId).Result;
            if (res.Success)
            {
                Objresponse = Mapper.Map<List<MemberCountByTGId>>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "POC Target group created successfully" : "No records found");
            return response;
        }


        public JSONResponse<bool> UpdateStatus(StatusChangeRequest request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.StatusChangeAsync(Mapper.Map<EliteMAPService.StatusChangeRequest>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Target group sent for approval successfully." : "No records found");
            return response;
        }


        public JSONResponse<bool> UpdateTG(TargetGroupReq request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.UpdateTGDetailsByIdAsync(Mapper.Map<EliteMAPService.TargetGroupReq>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Target group sent for approval successfully." : "No records found");
            return response;
        }
        public JSONResponse<bool> AddCampaign(CreateCampaignRequest request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.CreateCampaignAsync(Mapper.Map<EliteMAPService.CreateCampaignRequest>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Target group sent for approval successfully." : "No records found");
            return response;
        }
        public JSONResponse<bool> AddSMSCampaign(CreateSMSCampaign request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.CreateSMSCampaignAsync(Mapper.Map<EliteMAPService.CreateSMSCampaign>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Target group sent for approval successfully." : "No records found");
            return response;
        }
        public JSONResponse<bool> UpdateCampaign(CreateCampaignRequest request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.UpdateCampaignAsync(Mapper.Map<EliteMAPService.CreateCampaignRequest>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Target group sent for approval successfully." : "No records found");
            return response;
        }
        public JSONResponse<bool> UpdateSMSCampaign(CreateSMSCampaign request)
        {
            JSONResponse<bool> response = new JSONResponse<bool>();
            bool Objresponse = new bool();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.UpdateSMSCampaignAsync(Mapper.Map<EliteMAPService.CreateSMSCampaign>(request)).Result;
            if (res.Success)
            {
                Objresponse = res.Data;
            }
            response.SetSuccess(Objresponse, message: Objresponse ? "Target group sent for approval successfully." : "No records found");
            return response;
        }

        public JSONResponse<CreateCampaignRequest> GetEmailCampaignById(string CampaignId)
        {
            JSONResponse<CreateCampaignRequest> response = new JSONResponse<CreateCampaignRequest>();
            CreateCampaignRequest Objresponse = new CreateCampaignRequest();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetEmailCampaignByIdAsync(CampaignId).Result;
            if (res.Success)
            {
                Objresponse = Mapper.Map<CreateCampaignRequest>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "records found " : "No records found");
            return response;
        }

        public JSONResponse<CreateSMSCampaign> GetSmsCampaignById(string CampaignId)
        {
            JSONResponse<CreateSMSCampaign> response = new JSONResponse<CreateSMSCampaign>();
            CreateSMSCampaign Objresponse = new CreateSMSCampaign();
            var eliteMAPService = new EliteMAPService.EliteMAPServiceClient(EliteMAPService.EliteMAPServiceClient.EndpointConfiguration.EliteMAPHttpEP);
            var res = eliteMAPService.GetSmsCampaignByIdAsync(CampaignId).Result;
            if (res.Success)
            {
                Objresponse = Mapper.Map<CreateSMSCampaign>(res.Data);
            }
            response.SetSuccess(Objresponse, message: Objresponse != null ? "records found " : "No records found");
            return response;
        }
    }
}

