﻿namespace BusinessLayer
{
    public class ClassNameConstraints
    {
        public const string TGController = "TargetGroupController";
        public const string TemplateController = "TemplateController";
        public const string AttributeController = "AttributeController";
        public const string ProgramController = "ProgramController";
        public const string CampaignController = "CampaignController";
        public const string EliteMAPBL = "EliteMAPBL";
    }
}
