﻿using BusinessLayer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace SampleAPI.Controllers
{
    public class TemplatesController : Controller
    {
        private EliteMAPBL EMAPBL = new EliteMAPBL();
        [HttpPost]
        [Route("Templates/Add")]
        public JSONResponse<bool> AddTemplates([FromBody] AddTemplateReq request)
        {
            LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.AddTemplate, "Request Received For AddTemplate");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.AddTemplate(request));

                LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.AddTemplate, "Request Completed For AddTemplate");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TemplateController, MethodNameConstraints.AddTemplate, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }

        [HttpPost]
        [Route("Template/Update")]

        public JSONResponse<bool> UpdateTemplate([FromBody] AddTemplateReq request)
        {
            LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.UpdateTemplate, "Request Received For UpdateTemplate");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.UpdateTemplateDetailById(request));

                LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.UpdateTemplate, "Request Completed For UpdateTemplate");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TemplateController, MethodNameConstraints.UpdateTemplate, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpGet]
        [Route("Template/Records")]

        public JSONResponse<TemplateRecords> TemplateRecords(string Name, string Type, int PageNo, int PageSize)
        {
            LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.TemplateRecords, "Request Received For TemplateRecords");
            var response = new JSONResponse<TemplateRecords>();

            try
            {
                response = (EMAPBL.GetTemplateDashboard(Name, Type, PageNo, PageSize));

                LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.TemplateRecords, "Request Completed For TemplateRecords");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TemplateController, MethodNameConstraints.TemplateRecords, ex.Message, ex);
                JSONResponse<TemplateRecords> errorResponse = new JSONResponse<TemplateRecords>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }


        [HttpGet]
        [Route("TemplateDetails/{TemplateId}")]

        public JSONResponse<Templates> TemplateDetails(string TemplateId)
        {
            LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.TemplateDetails, "Request Received For AttributeList");
            var response = new JSONResponse<Templates>();

            try
            {
                response = (EMAPBL.GeTemplateDetailById(TemplateId));

                LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.TemplateDetails, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TemplateController, MethodNameConstraints.TemplateDetails, ex.Message, ex);
                JSONResponse<Templates> errorResponse = new JSONResponse<Templates>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }


        [HttpGet]
        [Route("Template/All")]

        public JSONResponse<RecordsList> AllTemplate(string Type, string ProgramId)
        {
            LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.AllTemplates, "Request Received For TemplateRecords");
            var response = new JSONResponse<RecordsList>();
            try
            {
                response = (EMAPBL.GetAllTemplates(Type, ProgramId));
                LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.AllTemplates, "Request Completed For TemplateRecords");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TemplateController, MethodNameConstraints.AllTemplates, ex.Message, ex);
                JSONResponse<RecordsList> errorResponse = new JSONResponse<RecordsList>();
                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };
                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }
        }

        [HttpPost]
        [Route("Template/MAP")]

        public JSONResponse<bool> MapTemplate([FromBody] MapTemplates mapTemplates)
        {
            LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.MAPTemplates, "Request Received For TemplateRecords");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.MapTemplate(mapTemplates));

                LogHandler.Info(ClassNameConstraints.TemplateController, MethodNameConstraints.MAPTemplates, "Request Completed For TemplateRecords");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.TemplateController, MethodNameConstraints.MAPTemplates, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }


        }
    }
}
