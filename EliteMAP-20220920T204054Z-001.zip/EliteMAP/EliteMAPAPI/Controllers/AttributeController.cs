﻿using BusinessLayer;
using EliteMAPService;
using LRAS.Brix.Core.Web;
using LRAS.Brix.Core.Web.Extension;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace SampleAPI.Controllers
{
    public class AttributeController : Controller
    {
        private EliteMAPBL EMAPBL = new EliteMAPBL();
        [HttpGet]
        [Route("Attributes/{ProgramId}")]
        public JSONResponse<List<AttributeList>> Attributes(string ProgramId)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeList, "Request Received For AttributeList");
            var response = new JSONResponse<List<AttributeList>>();

            try
            {
                response = (EMAPBL.GetAttributes(ProgramId));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeList, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.Programs, ex.Message, ex);
                JSONResponse<List<AttributeList>> errorResponse = new JSONResponse<List<AttributeList>>();

                var reason = new List<EliteMAPService.FailureReason>()
                {
                    new EliteMAPService.FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                // response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpPost]
        [Route("Attribute/Add")]
        public JSONResponse<bool> addAtribute([FromBody] AddAttributeReq request)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AddAttribute, "Request Received For AttributeList");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.AddAttribute(request));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AddAttribute, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.AddAttribute, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpPost]
        [Route("Attributes/Update")]

        public JSONResponse<bool> UpdateAtribute([FromBody] AddAttributeReq request)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.UpdateAttribute, "Request Received For AttributeList");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.UpdateAttributeDetailById(request));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.UpdateAttribute, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.UpdateAttribute, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return response;
            }

        }
        [HttpGet]
        [Route("Attributes/Records")]

        public JSONResponse<AttributeRecords> AtributeRecords(string Name, string DisplayName, int PageNo, int PageSize)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeRecords, "Request Received For AttributeList");
            var response = new JSONResponse<AttributeRecords>();

            try
            {
                response = (EMAPBL.GetAttributeDashboard(Name, DisplayName, PageNo, PageSize));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeRecords, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeRecords, ex.Message, ex);
                JSONResponse<AttributeRecords> errorResponse = new JSONResponse<AttributeRecords>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }

        [HttpGet]
        [Route("AttributeDetails/{AttributeId}")]

        public JSONResponse<Attributes> AtributeDetails(string AttributeId)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeDetails, "Request Received For AttributeList");
            var response = new JSONResponse<Attributes>();

            try
            {
                response = (EMAPBL.GetAttributeDetailById(AttributeId));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeDetails, "Request Completed For AttributeList");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeDetails, ex.Message, ex);
                JSONResponse<Attributes> errorResponse = new JSONResponse<Attributes>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
        [HttpGet]
        [Route("Attributes/All")]

        public JSONResponse<RecordsList> AllAttributes()
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeRecords, "Request Received For AttributeRecords");
            var response = new JSONResponse<RecordsList>();

            try
            {
                response = (EMAPBL.GetAllAttributes());

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeRecords, "Request Completed For AttributeRecords");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.AttributeRecords, ex.Message, ex);
                JSONResponse<RecordsList> errorResponse = new JSONResponse<RecordsList>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };
                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }
        }
        [HttpPost]
        [Route("Attributes/MAP")]

        public JSONResponse<bool> MAPAttributes([FromBody] MapAttributes mapAttributes)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.MAPAttributes, "Request Received For AttributeRecords");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.MapAttribute(mapAttributes));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.MAPAttributes, "Request Completed For AttributeRecords");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.MAPAttributes, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };
                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }
        }

        [HttpGet]
        [Route("Tags")]

        public JSONResponse<List<Tags>> Tags(string Name)
        {
            LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.Tags, "Request Received For Tags");
            var response = new JSONResponse<List<Tags>>();

            try
            {
                response = (EMAPBL.GetAllTags(Name));

                LogHandler.Info(ClassNameConstraints.AttributeController, MethodNameConstraints.Tags, "Request Completed For Tags");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.AttributeController, MethodNameConstraints.Tags, ex.Message, ex);
                JSONResponse<List<Tags>> errorResponse = new JSONResponse<List<Tags>>();

                var reason = new List<FailureReason>()
                {
                    new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response.SetContent(errorResponse);
                return errorResponse;
            }

        }
    }
}
