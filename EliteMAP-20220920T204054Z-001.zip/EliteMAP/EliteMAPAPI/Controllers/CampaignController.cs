﻿using BusinessLayer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace EliteMAPAPI.Controllers
{
    public class CampaignController : ControllerBase
    {
        private EliteMAPBL EMAPBL = new EliteMAPBL();
        [HttpGet]

        [Route("Campaign/Email")]
        public JSONResponse<EmailCampaignDashBoard> Email(string Name, string Status, DateTime startDate, DateTime endDate, int PageNo, int PageSize, string ProgramId)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<EmailCampaignDashBoard>();

            try
            {
                response = (EMAPBL.Email(Name, Status, startDate, endDate, PageNo, PageSize, ProgramId));

                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<EmailCampaignDashBoard> errorResponse = new JSONResponse<EmailCampaignDashBoard>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }

        [HttpGet]

        [Route("Campaign/SMS")]
        public JSONResponse<SMSCampaignDashBoard> SMS(string Name, string Status, DateTime startDate, DateTime endDate, int PageNo, int PageSize, string ProgramId)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.SMS, "Request Received For STD");
            var response = new JSONResponse<SMSCampaignDashBoard>();

            try
            {
                response = (EMAPBL.SMS(Name, Status, startDate, endDate, PageNo, PageSize, ProgramId));

                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.SMS, "Request Completed For STD");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.SMS, ex.Message, ex);
                JSONResponse<SMSCampaignDashBoard> errorResponse = new JSONResponse<SMSCampaignDashBoard>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }

        [HttpPost]
        [Route("Campaign/Add")]
        public JSONResponse<bool> AddCampaign([FromBody] CreateCampaignRequest request)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.AddCampaign(request));

                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }
        [HttpPost]
        [Route("SMSCampaign/Add")]
        public JSONResponse<bool> AddSMSCampaign([FromBody] CreateSMSCampaign request)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<bool>();
            try
            {
                response = (EMAPBL.AddSMSCampaign(request));
                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }
        }

        [HttpPost]
        [Route("Campaign/Update")]
        public JSONResponse<bool> UpdateCampaign([FromBody] CreateCampaignRequest request)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<bool>();

            try
            {
                response = (EMAPBL.AddCampaign(request));

                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }
        [HttpPost]
        [Route("SMSCampaign/Update")]
        public JSONResponse<bool> UpdateSMSCampaign([FromBody] CreateSMSCampaign request)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<bool>();
            try
            {
                response = (EMAPBL.AddSMSCampaign(request));
                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");
                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<bool> errorResponse = new JSONResponse<bool>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                return errorResponse;
            }
        }

        [HttpGet]

        [Route("Campaign/Email/{CampaignId}")]
        public JSONResponse<CreateCampaignRequest> EmailCampaignDetailById(string CampaignId)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<CreateCampaignRequest>();

            try
            {
                response = (EMAPBL.GetEmailCampaignById(CampaignId));

                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<CreateCampaignRequest> errorResponse = new JSONResponse<CreateCampaignRequest>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }
        [HttpGet]

        [Route("Campaign/SMS/{CampaignId}")]
        public JSONResponse<CreateSMSCampaign> SMSCampaignDetailById(string CampaignId)
        {
            LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Received For Email");
            var response = new JSONResponse<CreateSMSCampaign>();

            try
            {
                response = (EMAPBL.GetSmsCampaignById(CampaignId));

                LogHandler.Info(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, "Request Completed For Email");

                return response;
            }
            catch (Exception ex)
            {
                LogHandler.Error(ClassNameConstraints.CampaignController, MethodNameConstraints.Email, ex.Message, ex);
                JSONResponse<CreateSMSCampaign> errorResponse = new JSONResponse<CreateSMSCampaign>();

                var reason = new List<FailureReason>()
                {
                   new FailureReason { Error = ex.Message, Message = ex.Message }
                };

                errorResponse.SetException("No Records found.", reason);
                //response=(errorResponse);
                return errorResponse;
            }
        }

    }
}
