# Assignment 7
 Assignment 7 for CS 648
 
This project is a part of Assignment 5 for course **_CS648_**.

| Language | Platform | Author |
| -------- | --------|--------|
| HTML,CSS,JS |  Basic Web App| Shubham Kale|

# Sample HTML website 

Sample HTML/CSS web app that you can modify further and use it for assignment for course **_CS648_** . 


## Contributing
This project has adopted the [Prof Zak Basic Lectures](https://www.youtube.com/watch?v=7EWBHppYbmM&feature=youtu.be).
For more information 
contact [skale3178@sdsu.edu](mailto:skale3178@sdsu.edu) with any additional questions or comments.



 


 

